﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bingoGame
{
    public class Globals
    {
        public static SelectedNumbersListType selectedNumbersListObj =
            new SelectedNumbersListType();
    }
}
