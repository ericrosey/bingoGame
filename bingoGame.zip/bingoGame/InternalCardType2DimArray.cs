﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bingoGame
{
    public class InternalCardType2DimArray
    {
        public InternalCardType2DimArray(int BINGOCARDSIZE)
        {

        }
    }
}
